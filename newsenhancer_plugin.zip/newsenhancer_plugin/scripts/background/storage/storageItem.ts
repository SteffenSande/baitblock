
interface IStorageItem {
    key: string,
    data: any
}

export default IStorageItem;