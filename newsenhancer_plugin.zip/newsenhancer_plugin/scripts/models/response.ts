export interface IResponse {
    data: object,
    message: string;
    error: boolean
}