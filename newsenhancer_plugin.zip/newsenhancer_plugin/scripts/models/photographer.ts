
import {IPerson} from "./person";
export interface IPhotographer extends IPerson {}