export interface IRank {
    id: number,
    created: object,
    placement: number,
    of_total: number,
}
