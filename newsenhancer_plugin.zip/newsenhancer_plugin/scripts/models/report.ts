export interface IReport {
    category: string,
    news_site: string,
    article: string
}