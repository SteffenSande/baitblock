export interface IMessage {
    type: string,
    data: any
}