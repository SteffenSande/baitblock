export interface IArticleUrlTemplates {
    id: number,
    name: string,
    id_separator: string,
    id_position: number,
    id_length: number,
    news_site: number
}