export interface IHeadlineSummary {
    one_line: string,
    headline?: string
}