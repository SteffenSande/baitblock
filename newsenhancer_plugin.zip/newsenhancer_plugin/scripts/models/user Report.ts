export interface IUserReport {
    explanation: string,
    created: string
}